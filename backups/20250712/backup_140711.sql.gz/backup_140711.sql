--
-- PostgreSQL database dump
--

-- Dumped from database version 16.9 (Ubuntu 16.9-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.9 (Ubuntu 16.9-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: inventorysync
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO inventorysync;

--
-- Name: alert_templates; Type: TABLE; Schema: public; Owner: inventorysync
--

CREATE TABLE public.alert_templates (
    id integer NOT NULL,
    store_id integer NOT NULL,
    template_name character varying NOT NULL,
    description text,
    alert_type character varying NOT NULL,
    title_template character varying NOT NULL,
    message_template text NOT NULL,
    severity character varying,
    trigger_conditions json,
    notification_channels json,
    notification_config json,
    is_active boolean,
    auto_resolve_hours integer,
    usage_count integer,
    last_used_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.alert_templates OWNER TO inventorysync;

--
-- Name: alert_templates_id_seq; Type: SEQUENCE; Schema: public; Owner: inventorysync
--

CREATE SEQUENCE public.alert_templates_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.alert_templates_id_seq OWNER TO inventorysync;

--
-- Name: alert_templates_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: inventorysync
--

ALTER SEQUENCE public.alert_templates_id_seq OWNED BY public.alert_templates.id;


--
-- Name: alerts; Type: TABLE; Schema: public; Owner: inventorysync
--

CREATE TABLE public.alerts (
    id integer NOT NULL,
    store_id integer NOT NULL,
    alert_type character varying NOT NULL,
    severity character varying,
    title character varying NOT NULL,
    message text NOT NULL,
    product_sku character varying,
    location_name character varying,
    current_stock integer,
    recommended_action text,
    alert_source character varying,
    entity_type character varying,
    entity_id integer,
    custom_data json,
    notification_channels json,
    is_acknowledged boolean,
    acknowledged_at timestamp with time zone,
    acknowledged_by character varying,
    is_resolved boolean,
    resolved_at timestamp with time zone,
    resolved_by character varying,
    resolution_notes text,
    auto_resolve_at timestamp with time zone,
    is_auto_resolvable boolean,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.alerts OWNER TO inventorysync;

--
-- Name: alerts_id_seq; Type: SEQUENCE; Schema: public; Owner: inventorysync
--

CREATE SEQUENCE public.alerts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.alerts_id_seq OWNER TO inventorysync;

--
-- Name: alerts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: inventorysync
--

ALTER SEQUENCE public.alerts_id_seq OWNED BY public.alerts.id;


--
-- Name: custom_field_definitions; Type: TABLE; Schema: public; Owner: inventorysync
--

CREATE TABLE public.custom_field_definitions (
    id integer NOT NULL,
    store_id integer NOT NULL,
    field_name character varying NOT NULL,
    display_name character varying NOT NULL,
    field_type character varying NOT NULL,
    target_entity character varying NOT NULL,
    validation_rules json,
    is_required boolean,
    is_searchable boolean,
    is_filterable boolean,
    display_order integer,
    help_text text,
    default_value character varying,
    field_group character varying,
    industry_template character varying,
    is_active boolean,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.custom_field_definitions OWNER TO inventorysync;

--
-- Name: custom_field_definitions_id_seq; Type: SEQUENCE; Schema: public; Owner: inventorysync
--

CREATE SEQUENCE public.custom_field_definitions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.custom_field_definitions_id_seq OWNER TO inventorysync;

--
-- Name: custom_field_definitions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: inventorysync
--

ALTER SEQUENCE public.custom_field_definitions_id_seq OWNED BY public.custom_field_definitions.id;


--
-- Name: forecasts; Type: TABLE; Schema: public; Owner: inventorysync
--

CREATE TABLE public.forecasts (
    id integer NOT NULL,
    variant_id integer NOT NULL,
    location_id integer NOT NULL,
    forecast_date timestamp with time zone NOT NULL,
    forecast_period character varying,
    predicted_demand double precision NOT NULL,
    confidence_level double precision,
    historical_days integer,
    seasonal_factor double precision,
    trend_factor double precision,
    model_version character varying,
    accuracy_score double precision,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.forecasts OWNER TO inventorysync;

--
-- Name: forecasts_id_seq; Type: SEQUENCE; Schema: public; Owner: inventorysync
--

CREATE SEQUENCE public.forecasts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.forecasts_id_seq OWNER TO inventorysync;

--
-- Name: forecasts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: inventorysync
--

ALTER SEQUENCE public.forecasts_id_seq OWNED BY public.forecasts.id;


--
-- Name: inventory_items; Type: TABLE; Schema: public; Owner: inventorysync
--

CREATE TABLE public.inventory_items (
    id integer NOT NULL,
    store_id integer NOT NULL,
    location_id integer NOT NULL,
    variant_id integer NOT NULL,
    available_quantity integer,
    committed_quantity integer,
    on_hand_quantity integer,
    reorder_point integer,
    reorder_quantity integer,
    max_stock_level integer,
    lead_time_days integer,
    custom_data json,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.inventory_items OWNER TO inventorysync;

--
-- Name: inventory_items_id_seq; Type: SEQUENCE; Schema: public; Owner: inventorysync
--

CREATE SEQUENCE public.inventory_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.inventory_items_id_seq OWNER TO inventorysync;

--
-- Name: inventory_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: inventorysync
--

ALTER SEQUENCE public.inventory_items_id_seq OWNED BY public.inventory_items.id;


--
-- Name: inventory_movements; Type: TABLE; Schema: public; Owner: inventorysync
--

CREATE TABLE public.inventory_movements (
    id integer NOT NULL,
    inventory_item_id integer NOT NULL,
    movement_type character varying NOT NULL,
    quantity_change integer NOT NULL,
    reference_id character varying,
    unit_cost double precision,
    total_cost double precision,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.inventory_movements OWNER TO inventorysync;

--
-- Name: inventory_movements_id_seq; Type: SEQUENCE; Schema: public; Owner: inventorysync
--

CREATE SEQUENCE public.inventory_movements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.inventory_movements_id_seq OWNER TO inventorysync;

--
-- Name: inventory_movements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: inventorysync
--

ALTER SEQUENCE public.inventory_movements_id_seq OWNED BY public.inventory_movements.id;


--
-- Name: locations; Type: TABLE; Schema: public; Owner: inventorysync
--

CREATE TABLE public.locations (
    id integer NOT NULL,
    store_id integer NOT NULL,
    shopify_location_id character varying NOT NULL,
    name character varying NOT NULL,
    address text,
    city character varying,
    country character varying,
    is_active boolean,
    manages_inventory boolean,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.locations OWNER TO inventorysync;

--
-- Name: locations_id_seq; Type: SEQUENCE; Schema: public; Owner: inventorysync
--

CREATE SEQUENCE public.locations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.locations_id_seq OWNER TO inventorysync;

--
-- Name: locations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: inventorysync
--

ALTER SEQUENCE public.locations_id_seq OWNED BY public.locations.id;


--
-- Name: product_variants; Type: TABLE; Schema: public; Owner: inventorysync
--

CREATE TABLE public.product_variants (
    id integer NOT NULL,
    product_id integer NOT NULL,
    shopify_variant_id character varying NOT NULL,
    title character varying NOT NULL,
    sku character varying,
    barcode character varying,
    price double precision NOT NULL,
    cost_per_item double precision,
    weight double precision,
    weight_unit character varying,
    requires_shipping boolean,
    track_inventory boolean,
    inventory_policy character varying,
    custom_data json,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.product_variants OWNER TO inventorysync;

--
-- Name: product_variants_id_seq; Type: SEQUENCE; Schema: public; Owner: inventorysync
--

CREATE SEQUENCE public.product_variants_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.product_variants_id_seq OWNER TO inventorysync;

--
-- Name: product_variants_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: inventorysync
--

ALTER SEQUENCE public.product_variants_id_seq OWNED BY public.product_variants.id;


--
-- Name: products; Type: TABLE; Schema: public; Owner: inventorysync
--

CREATE TABLE public.products (
    id integer NOT NULL,
    store_id integer NOT NULL,
    shopify_product_id character varying NOT NULL,
    title character varying NOT NULL,
    handle character varying NOT NULL,
    product_type character varying,
    vendor character varying,
    price double precision,
    cost_per_item double precision,
    status character varying,
    custom_data json,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.products OWNER TO inventorysync;

--
-- Name: products_id_seq; Type: SEQUENCE; Schema: public; Owner: inventorysync
--

CREATE SEQUENCE public.products_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.products_id_seq OWNER TO inventorysync;

--
-- Name: products_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: inventorysync
--

ALTER SEQUENCE public.products_id_seq OWNED BY public.products.id;


--
-- Name: purchase_order_line_items; Type: TABLE; Schema: public; Owner: inventorysync
--

CREATE TABLE public.purchase_order_line_items (
    id integer NOT NULL,
    purchase_order_id integer NOT NULL,
    variant_id integer NOT NULL,
    quantity_ordered integer NOT NULL,
    quantity_received integer,
    unit_cost double precision NOT NULL,
    line_total double precision NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.purchase_order_line_items OWNER TO inventorysync;

--
-- Name: purchase_order_line_items_id_seq; Type: SEQUENCE; Schema: public; Owner: inventorysync
--

CREATE SEQUENCE public.purchase_order_line_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.purchase_order_line_items_id_seq OWNER TO inventorysync;

--
-- Name: purchase_order_line_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: inventorysync
--

ALTER SEQUENCE public.purchase_order_line_items_id_seq OWNED BY public.purchase_order_line_items.id;


--
-- Name: purchase_orders; Type: TABLE; Schema: public; Owner: inventorysync
--

CREATE TABLE public.purchase_orders (
    id integer NOT NULL,
    store_id integer NOT NULL,
    supplier_id integer NOT NULL,
    po_number character varying NOT NULL,
    status character varying,
    order_date timestamp with time zone,
    expected_delivery_date timestamp with time zone,
    actual_delivery_date timestamp with time zone,
    subtotal double precision,
    tax_amount double precision,
    shipping_cost double precision,
    total_amount double precision,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.purchase_orders OWNER TO inventorysync;

--
-- Name: purchase_orders_id_seq; Type: SEQUENCE; Schema: public; Owner: inventorysync
--

CREATE SEQUENCE public.purchase_orders_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.purchase_orders_id_seq OWNER TO inventorysync;

--
-- Name: purchase_orders_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: inventorysync
--

ALTER SEQUENCE public.purchase_orders_id_seq OWNED BY public.purchase_orders.id;


--
-- Name: stores; Type: TABLE; Schema: public; Owner: inventorysync
--

CREATE TABLE public.stores (
    id integer NOT NULL,
    shopify_store_id character varying NOT NULL,
    shop_domain character varying NOT NULL,
    store_name character varying NOT NULL,
    currency character varying,
    timezone character varying,
    subscription_plan character varying,
    subscription_status character varying,
    trial_ends_at timestamp with time zone,
    shopify_charge_id character varying,
    billing_cycle_start timestamp with time zone,
    billing_cycle_end timestamp with time zone,
    plan_price double precision,
    usage_charges double precision,
    billing_currency character varying,
    deletion_scheduled_at timestamp with time zone,
    access_token text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    shopify_domain character varying,
    shop_name character varying,
    email character varying
);


ALTER TABLE public.stores OWNER TO inventorysync;

--
-- Name: stores_id_seq; Type: SEQUENCE; Schema: public; Owner: inventorysync
--

CREATE SEQUENCE public.stores_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.stores_id_seq OWNER TO inventorysync;

--
-- Name: stores_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: inventorysync
--

ALTER SEQUENCE public.stores_id_seq OWNED BY public.stores.id;


--
-- Name: suppliers; Type: TABLE; Schema: public; Owner: inventorysync
--

CREATE TABLE public.suppliers (
    id integer NOT NULL,
    store_id integer NOT NULL,
    name character varying NOT NULL,
    contact_person character varying,
    email character varying,
    phone character varying,
    address text,
    city character varying,
    country character varying,
    payment_terms character varying,
    minimum_order_value double precision,
    lead_time_days integer,
    reliability_score double precision,
    quality_score double precision,
    is_active boolean,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.suppliers OWNER TO inventorysync;

--
-- Name: suppliers_id_seq; Type: SEQUENCE; Schema: public; Owner: inventorysync
--

CREATE SEQUENCE public.suppliers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.suppliers_id_seq OWNER TO inventorysync;

--
-- Name: suppliers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: inventorysync
--

ALTER SEQUENCE public.suppliers_id_seq OWNED BY public.suppliers.id;


--
-- Name: workflow_executions; Type: TABLE; Schema: public; Owner: inventorysync
--

CREATE TABLE public.workflow_executions (
    id integer NOT NULL,
    rule_id integer NOT NULL,
    trigger_data json,
    execution_status character varying,
    error_message text,
    execution_time_ms integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.workflow_executions OWNER TO inventorysync;

--
-- Name: workflow_executions_id_seq; Type: SEQUENCE; Schema: public; Owner: inventorysync
--

CREATE SEQUENCE public.workflow_executions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.workflow_executions_id_seq OWNER TO inventorysync;

--
-- Name: workflow_executions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: inventorysync
--

ALTER SEQUENCE public.workflow_executions_id_seq OWNED BY public.workflow_executions.id;


--
-- Name: workflow_rules; Type: TABLE; Schema: public; Owner: inventorysync
--

CREATE TABLE public.workflow_rules (
    id integer NOT NULL,
    store_id integer NOT NULL,
    rule_name character varying NOT NULL,
    description text,
    trigger_event character varying NOT NULL,
    trigger_conditions json,
    actions json,
    is_active boolean,
    execution_count integer,
    last_executed_at timestamp with time zone,
    priority integer,
    max_executions_per_hour integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.workflow_rules OWNER TO inventorysync;

--
-- Name: workflow_rules_id_seq; Type: SEQUENCE; Schema: public; Owner: inventorysync
--

CREATE SEQUENCE public.workflow_rules_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.workflow_rules_id_seq OWNER TO inventorysync;

--
-- Name: workflow_rules_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: inventorysync
--

ALTER SEQUENCE public.workflow_rules_id_seq OWNED BY public.workflow_rules.id;


--
-- Name: alert_templates id; Type: DEFAULT; Schema: public; Owner: inventorysync
--

ALTER TABLE ONLY public.alert_templates ALTER COLUMN id SET DEFAULT nextval('public.alert_templates_id_seq'::regclass);


--
-- Name: alerts id; Type: DEFAULT; Schema: public; Owner: inventorysync
--

ALTER TABLE ONLY public.alerts ALTER COLUMN id SET DEFAULT nextval('public.alerts_id_seq'::regclass);


--
-- Name: custom_field_definitions id; Type: DEFAULT; Schema: public; Owner: inventorysync
--

ALTER TABLE ONLY public.custom_field_definitions ALTER COLUMN id SET DEFAULT nextval('public.custom_field_definitions_id_seq'::regclass);


--
-- Name: forecasts id; Type: DEFAULT; Schema: public; Owner: inventorysync
--

ALTER TABLE ONLY public.forecasts ALTER COLUMN id SET DEFAULT nextval('public.forecasts_id_seq'::regclass);


--
-- Name: inventory_items id; Type: DEFAULT; Schema: public; Owner: inventorysync
--

ALTER TABLE ONLY public.inventory_items ALTER COLUMN id SET DEFAULT nextval('public.inventory_items_id_seq'::regclass);


--
-- Name: inventory_movements id; Type: DEFAULT; Schema: public; Owner: inventorysync
--

ALTER TABLE ONLY public.inventory_movements ALTER COLUMN id SET DEFAULT nextval('public.inventory_movements_id_seq'::regclass);


--
-- Name: locations id; Type: DEFAULT; Schema: public; Owner: inventorysync
--

ALTER TABLE ONLY public.locations ALTER COLUMN id SET DEFAULT nextval('public.locations_id_seq'::regclass);


--
-- Name: product_variants id; Type: DEFAULT; Schema: public; Owner: inventorysync
--

ALTER TABLE ONLY public.product_variants ALTER COLUMN id SET DEFAULT nextval('public.product_variants_id_seq'::regclass);


--
-- Name: products id; Type: DEFAULT; Schema: public; Owner: inventorysync
--

ALTER TABLE ONLY public.products ALTER COLUMN id SET DEFAULT nextval('public.products_id_seq'::regclass);


--
-- Name: purchase_order_line_items id; Type: DEFAULT; Schema: public; Owner: inventorysync
--

ALTER TABLE ONLY public.purchase_order_line_items ALTER COLUMN id SET DEFAULT nextval('public.purchase_order_line_items_id_seq'::regclass);


--
-- Name: purchase_orders id; Type: DEFAULT; Schema: public; Owner: inventorysync
--

ALTER TABLE ONLY public.purchase_orders ALTER COLUMN id SET DEFAULT nextval('public.purchase_orders_id_seq'::regclass);


--
-- Name: stores id; Type: DEFAULT; Schema: public; Owner: inventorysync
--

ALTER TABLE ONLY public.stores ALTER COLUMN id SET DEFAULT nextval('public.stores_id_seq'::regclass);


--
-- Name: suppliers id; Type: DEFAULT; Schema: public; Owner: inventorysync
--

ALTER TABLE ONLY public.suppliers ALTER COLUMN id SET DEFAULT nextval('public.suppliers_id_seq'::regclass);


--
-- Name: workflow_executions id; Type: DEFAULT; Schema: public; Owner: inventorysync
--

ALTER TABLE ONLY public.workflow_executions ALTER COLUMN id SET DEFAULT nextval('public.workflow_executions_id_seq'::regclass);


--
-- Name: workflow_rules id; Type: DEFAULT; Schema: public; Owner: inventorysync
--

ALTER TABLE ONLY public.workflow_rules ALTER COLUMN id SET DEFAULT nextval('public.workflow_rules_id_seq'::regclass);


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: inventorysync
--

COPY public.alembic_version (version_num) FROM stdin;
fix_store_schema_001
001_perf_indexes
\.


--
-- Data for Name: alert_templates; Type: TABLE DATA; Schema: public; Owner: inventorysync
--

COPY public.alert_templates (id, store_id, template_name, description, alert_type, title_template, message_template, severity, trigger_conditions, notification_channels, notification_config, is_active, auto_resolve_hours, usage_count, last_used_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: alerts; Type: TABLE DATA; Schema: public; Owner: inventorysync
--

COPY public.alerts (id, store_id, alert_type, severity, title, message, product_sku, location_name, current_stock, recommended_action, alert_source, entity_type, entity_id, custom_data, notification_channels, is_acknowledged, acknowledged_at, acknowledged_by, is_resolved, resolved_at, resolved_by, resolution_notes, auto_resolve_at, is_auto_resolvable, created_at, updated_at) FROM stdin;
1	1	low_stock	high	Low Stock Alert	Product ABC is running low on stock	\N	\N	\N	\N	system	\N	\N	{}	[]	f	\N	\N	f	\N	\N	\N	\N	f	2025-07-11 09:33:02+10	2025-07-11 09:33:02+10
2	1	overstock	medium	Overstock Warning	Product XYZ has excess inventory	\N	\N	\N	\N	system	\N	\N	{}	[]	f	\N	\N	f	\N	\N	\N	\N	f	2025-07-11 09:33:02+10	2025-07-11 09:33:02+10
3	1	manual	high	Test Alert - Custom Fields Working!	This is a test alert to verify the system is working correctly.	\N	\N	\N	No action needed - this is just a test	manual	\N	\N	{}	["email"]	f	\N	\N	f	\N	\N	\N	\N	f	2025-07-11 09:34:56+10	2025-07-11 09:34:56+10
\.


--
-- Data for Name: custom_field_definitions; Type: TABLE DATA; Schema: public; Owner: inventorysync
--

COPY public.custom_field_definitions (id, store_id, field_name, display_name, field_type, target_entity, validation_rules, is_required, is_searchable, is_filterable, display_order, help_text, default_value, field_group, industry_template, is_active, created_at, updated_at) FROM stdin;
1	1	material	Material	text	product	{}	f	t	t	0	Product material type	\N	basic	\N	t	2025-07-11 09:33:02+10	2025-07-11 09:33:02+10
2	1	size	Size	select	product	{}	f	t	t	0	Product size	\N	basic	\N	t	2025-07-11 09:33:02+10	2025-07-11 09:33:02+10
3	1	color	Color	text	product	{}	f	t	t	0	Product color	\N	basic	\N	t	2025-07-11 09:33:02+10	2025-07-11 09:33:02+10
4	1	brand	Brand Name	text	product	{}	t	t	t	0	Product brand		basic	\N	t	2025-07-11 09:34:56+10	2025-07-11 09:34:56+10
\.


--
-- Data for Name: forecasts; Type: TABLE DATA; Schema: public; Owner: inventorysync
--

COPY public.forecasts (id, variant_id, location_id, forecast_date, forecast_period, predicted_demand, confidence_level, historical_days, seasonal_factor, trend_factor, model_version, accuracy_score, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: inventory_items; Type: TABLE DATA; Schema: public; Owner: inventorysync
--

COPY public.inventory_items (id, store_id, location_id, variant_id, available_quantity, committed_quantity, on_hand_quantity, reorder_point, reorder_quantity, max_stock_level, lead_time_days, custom_data, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: inventory_movements; Type: TABLE DATA; Schema: public; Owner: inventorysync
--

COPY public.inventory_movements (id, inventory_item_id, movement_type, quantity_change, reference_id, unit_cost, total_cost, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: locations; Type: TABLE DATA; Schema: public; Owner: inventorysync
--

COPY public.locations (id, store_id, shopify_location_id, name, address, city, country, is_active, manages_inventory, created_at, updated_at) FROM stdin;
1	1	70229753931	Shop location	\N	\N	AU	t	t	2025-07-07 11:31:24+10	2025-07-07 11:31:24+10
\.


--
-- Data for Name: product_variants; Type: TABLE DATA; Schema: public; Owner: inventorysync
--

COPY public.product_variants (id, product_id, shopify_variant_id, title, sku, barcode, price, cost_per_item, weight, weight_unit, requires_shipping, track_inventory, inventory_policy, custom_data, created_at, updated_at) FROM stdin;
1	1	41588946698315	Small / Blue	TS-001-S-BLU	\N	29.99	\N	0	kg	t	t	deny	{}	2025-07-09 21:45:58+10	2025-07-09 21:45:58+10
2	1	41588946731083	Medium / Blue	TS-001-M-BLU	\N	29.99	\N	0	kg	t	t	deny	{}	2025-07-09 21:45:58+10	2025-07-09 21:45:58+10
3	1	41588946763851	Large / Blue	TS-001-L-BLU	\N	29.99	\N	0	kg	t	t	deny	{}	2025-07-09 21:45:58+10	2025-07-09 21:45:58+10
4	1	41588946796619	Small / Green	TS-001-S-GRN	\N	29.99	\N	0	kg	t	t	deny	{}	2025-07-09 21:45:58+10	2025-07-09 21:45:58+10
5	2	41588946632779	Black	WH-001-BLK	\N	199.99	\N	0	kg	t	t	deny	{}	2025-07-09 21:45:57+10	2025-07-09 21:45:57+10
6	2	41588946665547	White	WH-001-WHT	\N	199.99	\N	0	kg	t	t	deny	{}	2025-07-09 21:45:57+10	2025-07-09 21:45:57+10
7	3	41588946829387	500ml	WB-001-500	\N	24.99	\N	0	kg	t	t	deny	{}	2025-07-09 21:45:59+10	2025-07-09 21:45:59+10
8	3	41588946862155	750ml	WB-001-750	\N	29.99	\N	0	kg	t	t	deny	{}	2025-07-09 21:45:59+10	2025-07-09 21:45:59+10
9	4	41234567890123	Default Title	TEST-001	123456789	19.99	24.99	0.5	kg	t	t	deny	{}	2025-07-09 22:02:08.722903+10	2025-07-09 22:02:08.722904+10
10	5	41588976517195	Default Title	\N		5	\N	0	kg	t	f	deny	{}	2025-07-09 22:19:40+10	2025-07-09 22:19:40+10
\.


--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: inventorysync
--

COPY public.products (id, store_id, shopify_product_id, title, handle, product_type, vendor, price, cost_per_item, status, custom_data, created_at, updated_at) FROM stdin;
1	1	7398816120907	Organic Cotton T-Shirt	organic-cotton-t-shirt	Clothing	EcoWear	\N	\N	active	{}	2025-07-09 21:45:58+10	2025-07-09 21:46:02+10
2	1	7398816088139	Premium Wireless Headphones - Updated	premium-wireless-headphones-updated	Electronics	TechCorp	\N	\N	active	{}	2025-07-09 21:45:57+10	2025-07-09 22:02:08.734434+10
3	1	7398816153675	Stainless Steel Water Bottle	stainless-steel-water-bottle	Accessories	HydroLife	\N	\N	active	{}	2025-07-09 21:45:59+10	2025-07-09 21:46:00+10
4	1	7398816999999	Test Webhook Product	test-webhook-product	Test	Test Vendor	\N	\N	active	{}	2025-07-09 22:02:08.722893+10	2025-07-09 22:02:08.7229+10
5	1	7398824214603	Purple Glow Bug	purple-glow-bug		inventorysync-dev	\N	\N	active	{}	2025-07-09 22:19:39+10	2025-07-09 22:19:40+10
\.


--
-- Data for Name: purchase_order_line_items; Type: TABLE DATA; Schema: public; Owner: inventorysync
--

COPY public.purchase_order_line_items (id, purchase_order_id, variant_id, quantity_ordered, quantity_received, unit_cost, line_total, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: purchase_orders; Type: TABLE DATA; Schema: public; Owner: inventorysync
--

COPY public.purchase_orders (id, store_id, supplier_id, po_number, status, order_date, expected_delivery_date, actual_delivery_date, subtotal, tax_amount, shipping_cost, total_amount, notes, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: stores; Type: TABLE DATA; Schema: public; Owner: inventorysync
--

COPY public.stores (id, shopify_store_id, shop_domain, store_name, currency, timezone, subscription_plan, subscription_status, trial_ends_at, shopify_charge_id, billing_cycle_start, billing_cycle_end, plan_price, usage_charges, billing_currency, deletion_scheduled_at, access_token, created_at, updated_at, shopify_domain, shop_name, email) FROM stdin;
1	test_store_123	inventorysync-dev.myshopify.com	InventorySync Dev Store	USD	UTC	starter	trial	\N	\N	\N	\N	0	0	USD	\N	test_access_token	2025-07-11 09:33:02+10	2025-07-11 09:33:02+10	inventorysync-dev.myshopify.com	InventorySync Dev Store	\N
\.


--
-- Data for Name: suppliers; Type: TABLE DATA; Schema: public; Owner: inventorysync
--

COPY public.suppliers (id, store_id, name, contact_person, email, phone, address, city, country, payment_terms, minimum_order_value, lead_time_days, reliability_score, quality_score, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: workflow_executions; Type: TABLE DATA; Schema: public; Owner: inventorysync
--

COPY public.workflow_executions (id, rule_id, trigger_data, execution_status, error_message, execution_time_ms, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: workflow_rules; Type: TABLE DATA; Schema: public; Owner: inventorysync
--

COPY public.workflow_rules (id, store_id, rule_name, description, trigger_event, trigger_conditions, actions, is_active, execution_count, last_executed_at, priority, max_executions_per_hour, created_at, updated_at) FROM stdin;
\.


--
-- Name: alert_templates_id_seq; Type: SEQUENCE SET; Schema: public; Owner: inventorysync
--

SELECT pg_catalog.setval('public.alert_templates_id_seq', 1, false);


--
-- Name: alerts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: inventorysync
--

SELECT pg_catalog.setval('public.alerts_id_seq', 3, true);


--
-- Name: custom_field_definitions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: inventorysync
--

SELECT pg_catalog.setval('public.custom_field_definitions_id_seq', 4, true);


--
-- Name: forecasts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: inventorysync
--

SELECT pg_catalog.setval('public.forecasts_id_seq', 1, false);


--
-- Name: inventory_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: inventorysync
--

SELECT pg_catalog.setval('public.inventory_items_id_seq', 1, false);


--
-- Name: inventory_movements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: inventorysync
--

SELECT pg_catalog.setval('public.inventory_movements_id_seq', 1, false);


--
-- Name: locations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: inventorysync
--

SELECT pg_catalog.setval('public.locations_id_seq', 1, true);


--
-- Name: product_variants_id_seq; Type: SEQUENCE SET; Schema: public; Owner: inventorysync
--

SELECT pg_catalog.setval('public.product_variants_id_seq', 10, true);


--
-- Name: products_id_seq; Type: SEQUENCE SET; Schema: public; Owner: inventorysync
--

SELECT pg_catalog.setval('public.products_id_seq', 5, true);


--
-- Name: purchase_order_line_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: inventorysync
--

SELECT pg_catalog.setval('public.purchase_order_line_items_id_seq', 1, false);


--
-- Name: purchase_orders_id_seq; Type: SEQUENCE SET; Schema: public; Owner: inventorysync
--

SELECT pg_catalog.setval('public.purchase_orders_id_seq', 1, false);


--
-- Name: stores_id_seq; Type: SEQUENCE SET; Schema: public; Owner: inventorysync
--

SELECT pg_catalog.setval('public.stores_id_seq', 1, true);


--
-- Name: suppliers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: inventorysync
--

SELECT pg_catalog.setval('public.suppliers_id_seq', 1, false);


--
-- Name: workflow_executions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: inventorysync
--

SELECT pg_catalog.setval('public.workflow_executions_id_seq', 1, false);


--
-- Name: workflow_rules_id_seq; Type: SEQUENCE SET; Schema: public; Owner: inventorysync
--

SELECT pg_catalog.setval('public.workflow_rules_id_seq', 1, true);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: inventorysync
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: alert_templates alert_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: inventorysync
--

ALTER TABLE ONLY public.alert_templates
    ADD CONSTRAINT alert_templates_pkey PRIMARY KEY (id);


--
-- Name: alerts alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: inventorysync
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_pkey PRIMARY KEY (id);


--
-- Name: custom_field_definitions custom_field_definitions_pkey; Type: CONSTRAINT; Schema: public; Owner: inventorysync
--

ALTER TABLE ONLY public.custom_field_definitions
    ADD CONSTRAINT custom_field_definitions_pkey PRIMARY KEY (id);


--
-- Name: forecasts forecasts_pkey; Type: CONSTRAINT; Schema: public; Owner: inventorysync
--

ALTER TABLE ONLY public.forecasts
    ADD CONSTRAINT forecasts_pkey PRIMARY KEY (id);


--
-- Name: inventory_items inventory_items_pkey; Type: CONSTRAINT; Schema: public; Owner: inventorysync
--

ALTER TABLE ONLY public.inventory_items
    ADD CONSTRAINT inventory_items_pkey PRIMARY KEY (id);


--
-- Name: inventory_movements inventory_movements_pkey; Type: CONSTRAINT; Schema: public; Owner: inventorysync
--

ALTER TABLE ONLY public.inventory_movements
    ADD CONSTRAINT inventory_movements_pkey PRIMARY KEY (id);


--
-- Name: locations locations_pkey; Type: CONSTRAINT; Schema: public; Owner: inventorysync
--

ALTER TABLE ONLY public.locations
    ADD CONSTRAINT locations_pkey PRIMARY KEY (id);


--
-- Name: product_variants product_variants_pkey; Type: CONSTRAINT; Schema: public; Owner: inventorysync
--

ALTER TABLE ONLY public.product_variants
    ADD CONSTRAINT product_variants_pkey PRIMARY KEY (id);


--
-- Name: products products_pkey; Type: CONSTRAINT; Schema: public; Owner: inventorysync
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_pkey PRIMARY KEY (id);


--
-- Name: purchase_order_line_items purchase_order_line_items_pkey; Type: CONSTRAINT; Schema: public; Owner: inventorysync
--

ALTER TABLE ONLY public.purchase_order_line_items
    ADD CONSTRAINT purchase_order_line_items_pkey PRIMARY KEY (id);


--
-- Name: purchase_orders purchase_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: inventorysync
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_pkey PRIMARY KEY (id);


--
-- Name: purchase_orders purchase_orders_po_number_key; Type: CONSTRAINT; Schema: public; Owner: inventorysync
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_po_number_key UNIQUE (po_number);


--
-- Name: stores stores_pkey; Type: CONSTRAINT; Schema: public; Owner: inventorysync
--

ALTER TABLE ONLY public.stores
    ADD CONSTRAINT stores_pkey PRIMARY KEY (id);


--
-- Name: suppliers suppliers_pkey; Type: CONSTRAINT; Schema: public; Owner: inventorysync
--

ALTER TABLE ONLY public.suppliers
    ADD CONSTRAINT suppliers_pkey PRIMARY KEY (id);


--
-- Name: workflow_executions workflow_executions_pkey; Type: CONSTRAINT; Schema: public; Owner: inventorysync
--

ALTER TABLE ONLY public.workflow_executions
    ADD CONSTRAINT workflow_executions_pkey PRIMARY KEY (id);


--
-- Name: workflow_rules workflow_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: inventorysync
--

ALTER TABLE ONLY public.workflow_rules
    ADD CONSTRAINT workflow_rules_pkey PRIMARY KEY (id);


--
-- Name: idx_alerts_custom_data; Type: INDEX; Schema: public; Owner: inventorysync
--

CREATE INDEX idx_alerts_custom_data ON public.alerts USING gin (((custom_data)::jsonb));


--
-- Name: idx_alerts_store_id_created_at; Type: INDEX; Schema: public; Owner: inventorysync
--

CREATE INDEX idx_alerts_store_id_created_at ON public.alerts USING btree (store_id, created_at DESC);


--
-- Name: idx_alerts_store_type; Type: INDEX; Schema: public; Owner: inventorysync
--

CREATE INDEX idx_alerts_store_type ON public.alerts USING btree (store_id, alert_type);


--
-- Name: idx_custom_fields_store_entity; Type: INDEX; Schema: public; Owner: inventorysync
--

CREATE INDEX idx_custom_fields_store_entity ON public.custom_field_definitions USING btree (store_id, target_entity);


--
-- Name: idx_custom_fields_store_id; Type: INDEX; Schema: public; Owner: inventorysync
--

CREATE INDEX idx_custom_fields_store_id ON public.custom_field_definitions USING btree (store_id);


--
-- Name: idx_inventory_custom_data; Type: INDEX; Schema: public; Owner: inventorysync
--

CREATE INDEX idx_inventory_custom_data ON public.inventory_items USING gin (((custom_data)::jsonb));


--
-- Name: idx_inventory_items_location_id; Type: INDEX; Schema: public; Owner: inventorysync
--

CREATE INDEX idx_inventory_items_location_id ON public.inventory_items USING btree (location_id);


--
-- Name: idx_inventory_items_variant_id; Type: INDEX; Schema: public; Owner: inventorysync
--

CREATE INDEX idx_inventory_items_variant_id ON public.inventory_items USING btree (variant_id);


--
-- Name: idx_inventory_variant_location; Type: INDEX; Schema: public; Owner: inventorysync
--

CREATE INDEX idx_inventory_variant_location ON public.inventory_items USING btree (variant_id, location_id);


--
-- Name: idx_product_variants_product_id; Type: INDEX; Schema: public; Owner: inventorysync
--

CREATE INDEX idx_product_variants_product_id ON public.product_variants USING btree (product_id);


--
-- Name: idx_product_variants_sku; Type: INDEX; Schema: public; Owner: inventorysync
--

CREATE INDEX idx_product_variants_sku ON public.product_variants USING btree (sku);


--
-- Name: idx_products_custom_data; Type: INDEX; Schema: public; Owner: inventorysync
--

CREATE INDEX idx_products_custom_data ON public.products USING gin (((custom_data)::jsonb));


--
-- Name: idx_products_store_id; Type: INDEX; Schema: public; Owner: inventorysync
--

CREATE INDEX idx_products_store_id ON public.products USING btree (store_id);


--
-- Name: idx_stores_shop_domain; Type: INDEX; Schema: public; Owner: inventorysync
--

CREATE INDEX idx_stores_shop_domain ON public.stores USING btree (shop_domain);


--
-- Name: idx_workflow_rules_store_id; Type: INDEX; Schema: public; Owner: inventorysync
--

CREATE INDEX idx_workflow_rules_store_id ON public.workflow_rules USING btree (store_id);


--
-- Name: ix_alert_templates_id; Type: INDEX; Schema: public; Owner: inventorysync
--

CREATE INDEX ix_alert_templates_id ON public.alert_templates USING btree (id);


--
-- Name: ix_alerts_id; Type: INDEX; Schema: public; Owner: inventorysync
--

CREATE INDEX ix_alerts_id ON public.alerts USING btree (id);


--
-- Name: ix_custom_field_definitions_id; Type: INDEX; Schema: public; Owner: inventorysync
--

CREATE INDEX ix_custom_field_definitions_id ON public.custom_field_definitions USING btree (id);


--
-- Name: ix_forecasts_id; Type: INDEX; Schema: public; Owner: inventorysync
--

CREATE INDEX ix_forecasts_id ON public.forecasts USING btree (id);


--
-- Name: ix_inventory_items_id; Type: INDEX; Schema: public; Owner: inventorysync
--

CREATE INDEX ix_inventory_items_id ON public.inventory_items USING btree (id);


--
-- Name: ix_inventory_movements_id; Type: INDEX; Schema: public; Owner: inventorysync
--

CREATE INDEX ix_inventory_movements_id ON public.inventory_movements USING btree (id);


--
-- Name: ix_locations_id; Type: INDEX; Schema: public; Owner: inventorysync
--

CREATE INDEX ix_locations_id ON public.locations USING btree (id);


--
-- Name: ix_locations_shopify_location_id; Type: INDEX; Schema: public; Owner: inventorysync
--

CREATE INDEX ix_locations_shopify_location_id ON public.locations USING btree (shopify_location_id);


--
-- Name: ix_product_variants_id; Type: INDEX; Schema: public; Owner: inventorysync
--

CREATE INDEX ix_product_variants_id ON public.product_variants USING btree (id);


--
-- Name: ix_product_variants_shopify_variant_id; Type: INDEX; Schema: public; Owner: inventorysync
--

CREATE INDEX ix_product_variants_shopify_variant_id ON public.product_variants USING btree (shopify_variant_id);


--
-- Name: ix_product_variants_sku; Type: INDEX; Schema: public; Owner: inventorysync
--

CREATE INDEX ix_product_variants_sku ON public.product_variants USING btree (sku);


--
-- Name: ix_products_id; Type: INDEX; Schema: public; Owner: inventorysync
--

CREATE INDEX ix_products_id ON public.products USING btree (id);


--
-- Name: ix_products_shopify_product_id; Type: INDEX; Schema: public; Owner: inventorysync
--

CREATE INDEX ix_products_shopify_product_id ON public.products USING btree (shopify_product_id);


--
-- Name: ix_purchase_order_line_items_id; Type: INDEX; Schema: public; Owner: inventorysync
--

CREATE INDEX ix_purchase_order_line_items_id ON public.purchase_order_line_items USING btree (id);


--
-- Name: ix_purchase_orders_id; Type: INDEX; Schema: public; Owner: inventorysync
--

CREATE INDEX ix_purchase_orders_id ON public.purchase_orders USING btree (id);


--
-- Name: ix_stores_id; Type: INDEX; Schema: public; Owner: inventorysync
--

CREATE INDEX ix_stores_id ON public.stores USING btree (id);


--
-- Name: ix_stores_shopify_store_id; Type: INDEX; Schema: public; Owner: inventorysync
--

CREATE UNIQUE INDEX ix_stores_shopify_store_id ON public.stores USING btree (shopify_store_id);


--
-- Name: ix_suppliers_id; Type: INDEX; Schema: public; Owner: inventorysync
--

CREATE INDEX ix_suppliers_id ON public.suppliers USING btree (id);


--
-- Name: ix_workflow_executions_id; Type: INDEX; Schema: public; Owner: inventorysync
--

CREATE INDEX ix_workflow_executions_id ON public.workflow_executions USING btree (id);


--
-- Name: ix_workflow_rules_id; Type: INDEX; Schema: public; Owner: inventorysync
--

CREATE INDEX ix_workflow_rules_id ON public.workflow_rules USING btree (id);


--
-- Name: alert_templates alert_templates_store_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: inventorysync
--

ALTER TABLE ONLY public.alert_templates
    ADD CONSTRAINT alert_templates_store_id_fkey FOREIGN KEY (store_id) REFERENCES public.stores(id);


--
-- Name: alerts alerts_store_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: inventorysync
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_store_id_fkey FOREIGN KEY (store_id) REFERENCES public.stores(id);


--
-- Name: custom_field_definitions custom_field_definitions_store_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: inventorysync
--

ALTER TABLE ONLY public.custom_field_definitions
    ADD CONSTRAINT custom_field_definitions_store_id_fkey FOREIGN KEY (store_id) REFERENCES public.stores(id);


--
-- Name: forecasts forecasts_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: inventorysync
--

ALTER TABLE ONLY public.forecasts
    ADD CONSTRAINT forecasts_location_id_fkey FOREIGN KEY (location_id) REFERENCES public.locations(id);


--
-- Name: forecasts forecasts_variant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: inventorysync
--

ALTER TABLE ONLY public.forecasts
    ADD CONSTRAINT forecasts_variant_id_fkey FOREIGN KEY (variant_id) REFERENCES public.product_variants(id);


--
-- Name: inventory_items inventory_items_location_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: inventorysync
--

ALTER TABLE ONLY public.inventory_items
    ADD CONSTRAINT inventory_items_location_id_fkey FOREIGN KEY (location_id) REFERENCES public.locations(id);


--
-- Name: inventory_items inventory_items_store_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: inventorysync
--

ALTER TABLE ONLY public.inventory_items
    ADD CONSTRAINT inventory_items_store_id_fkey FOREIGN KEY (store_id) REFERENCES public.stores(id);


--
-- Name: inventory_items inventory_items_variant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: inventorysync
--

ALTER TABLE ONLY public.inventory_items
    ADD CONSTRAINT inventory_items_variant_id_fkey FOREIGN KEY (variant_id) REFERENCES public.product_variants(id);


--
-- Name: inventory_movements inventory_movements_inventory_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: inventorysync
--

ALTER TABLE ONLY public.inventory_movements
    ADD CONSTRAINT inventory_movements_inventory_item_id_fkey FOREIGN KEY (inventory_item_id) REFERENCES public.inventory_items(id);


--
-- Name: locations locations_store_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: inventorysync
--

ALTER TABLE ONLY public.locations
    ADD CONSTRAINT locations_store_id_fkey FOREIGN KEY (store_id) REFERENCES public.stores(id);


--
-- Name: product_variants product_variants_product_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: inventorysync
--

ALTER TABLE ONLY public.product_variants
    ADD CONSTRAINT product_variants_product_id_fkey FOREIGN KEY (product_id) REFERENCES public.products(id);


--
-- Name: products products_store_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: inventorysync
--

ALTER TABLE ONLY public.products
    ADD CONSTRAINT products_store_id_fkey FOREIGN KEY (store_id) REFERENCES public.stores(id);


--
-- Name: purchase_order_line_items purchase_order_line_items_purchase_order_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: inventorysync
--

ALTER TABLE ONLY public.purchase_order_line_items
    ADD CONSTRAINT purchase_order_line_items_purchase_order_id_fkey FOREIGN KEY (purchase_order_id) REFERENCES public.purchase_orders(id);


--
-- Name: purchase_order_line_items purchase_order_line_items_variant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: inventorysync
--

ALTER TABLE ONLY public.purchase_order_line_items
    ADD CONSTRAINT purchase_order_line_items_variant_id_fkey FOREIGN KEY (variant_id) REFERENCES public.product_variants(id);


--
-- Name: purchase_orders purchase_orders_store_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: inventorysync
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_store_id_fkey FOREIGN KEY (store_id) REFERENCES public.stores(id);


--
-- Name: purchase_orders purchase_orders_supplier_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: inventorysync
--

ALTER TABLE ONLY public.purchase_orders
    ADD CONSTRAINT purchase_orders_supplier_id_fkey FOREIGN KEY (supplier_id) REFERENCES public.suppliers(id);


--
-- Name: suppliers suppliers_store_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: inventorysync
--

ALTER TABLE ONLY public.suppliers
    ADD CONSTRAINT suppliers_store_id_fkey FOREIGN KEY (store_id) REFERENCES public.stores(id);


--
-- Name: workflow_executions workflow_executions_rule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: inventorysync
--

ALTER TABLE ONLY public.workflow_executions
    ADD CONSTRAINT workflow_executions_rule_id_fkey FOREIGN KEY (rule_id) REFERENCES public.workflow_rules(id);


--
-- Name: workflow_rules workflow_rules_store_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: inventorysync
--

ALTER TABLE ONLY public.workflow_rules
    ADD CONSTRAINT workflow_rules_store_id_fkey FOREIGN KEY (store_id) REFERENCES public.stores(id);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT ALL ON SCHEMA public TO inventorysync;


--
-- PostgreSQL database dump complete
--

